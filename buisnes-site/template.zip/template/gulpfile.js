var gulp = require("gulp"),
	uglify = require('gulp-uglify'),
	watch = require('gulp-watch'),
	rimraf = require('rimraf'),
	concat = require('gulp-concat');

gulp.task('js:build', function() {
	return gulp.src('app/js/*.js')
		.pipe(concat("all.js"))
		.pipe(uglify())
		.pipe(gulp.dest('build'));
});

gulp.task('watch', function() {
	watch("app/js/**/*.js", function(event, cb) {
		gulp.start('js:build');
	});
});

gulp.task('clean', function(cb) {
	rimraf("./build", cb);
});
